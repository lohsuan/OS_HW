# Programming Project 6-2

## How to Run
1. open terminal in this directory
2. enter `make` to compile
3. enter `make exec` or `./main` to execute
4. enter `make clean` to clean up (optional)