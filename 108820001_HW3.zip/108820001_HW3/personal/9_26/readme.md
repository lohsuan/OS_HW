# Programming Problems 9.26

## How to Run
This file was written in C language. Please make sure your environment work well with gcc.

1. open terminal in this directory
2. enter `make` to compile
3. enter `make exec` or `./main` to execute
4. enter `make clean` to clean up