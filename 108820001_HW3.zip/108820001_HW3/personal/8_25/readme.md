# Programming Problems 8.25
計算 32-bit virtual address, 4-KB page size virtual memory 對應的 page number 及 offset

## How to Run
This file was written in C language. Please make sure your environment work well with gcc.

1. open terminal in this directory
2. enter `make` to compile
3. enter `./main <address you want to check>` to execute
4. enter `make clean` to clean up