# Programming Problems 7.17
利用 multithread 實作南北邊的農夫要通過僅一台車寬度的橋，並避免 deadlock。

## How to Run
This file was written in C++. Please make sure your environment work well with g++.

1. open terminal in this directory
2. enter `make` to compile
3. enter `make exec` or `./main` to execute
4. enter `make clean` to clean up