# Programming Problems 12.26
實作 FCFS、SSTF、SCAN、C-SCAN 演算法

## How to Run
enter `python3 main.py` to execute