# Programming Problems 11.13
根據指令執行，了解 hard link、soft link。

## How to Run
main.sh contains all scripts to run
you should prepare file1.txt and file3.txt before run those scripts on your computer.
